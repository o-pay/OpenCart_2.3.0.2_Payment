<?php
$prefix = 'opay_';
$model_path = 'extension/payment/opay';

// Set the checkout form action
$data[$prefix . 'action'] = $this->url->link($model_path . '/redirect', '', true);

// Get the translations
$this->load->language($model_path);

// Get the translation of payment methods
$opay_payment_methods = $this->config->get($prefix . 'payment_methods');
if (is_array($opay_payment_methods)) {
    foreach ($opay_payment_methods as $payment_type => $value) {
        $data['opay_payment_methods'][$payment_type] = $this->language->get($prefix . 'text_' . $value);
    }
}
?>